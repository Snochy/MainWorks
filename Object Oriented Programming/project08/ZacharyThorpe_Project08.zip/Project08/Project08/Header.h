// CS 1410 Programming Project #2
// Copyright 2014, Utah Valley University
//Author: Roger deBry
// Date last modified: October 2015
// Header file for main - constants and function prologues
// =================================================
// CS 1410 Programming Project #8
// Copyright 2015, Utah Valley University
//Author: Roger deBry
// Date last modified: April 2015
// Header file for main
// =======================================
#include <iostream>
#include <string>
#include "MyVector.h"
using namespace std;

const double FRACTION = 0.5;