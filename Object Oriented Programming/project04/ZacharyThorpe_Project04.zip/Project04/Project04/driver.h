// Project #12 Driver header file
// CS 1400  (your section)
// Your name
// the date
// ------------------------
#include <iostream>
#include "MyVector.h"
using namespace std;

const int TEST_VALUE1 = 21;
const int TEST_VALUE2 = 31;
const int TEST_VALUE3 = 41;

const int MAX = 12;